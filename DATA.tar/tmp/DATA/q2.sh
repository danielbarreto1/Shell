echo "Listando o conteúdo do diretório $1"
ls $1
echo -e "\n"
echo "Listando o conteúdo do diretório $2"
ls $2

