echo "Nada do que foi será de novo do jeito que já foi um dia"
